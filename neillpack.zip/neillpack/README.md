# My Mindustry test mod

Idk what to do
