
print("Setup done")

items = {}
blocks = {}
units = {}
effects = {}
